const Home = () => <h1>Welcome to Clothing Shop</h1>;
export default Home;
