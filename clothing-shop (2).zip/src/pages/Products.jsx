import { useState } from 'react';
import { Link } from 'react-router-dom';
import tshirt from '../assets/tshirt.jpg';
import jacket from '../assets/jacket.jpg';
import pants from '../assets/pants.jpg';

const items = [
  { id: 1, name: '티셔츠', price: 20000, image: tshirt },
  { id: 2, name: '자켓', price: 50000, image: jacket },
  { id: 3, name: '바지', price: 30000, image: pants },
];

const Products = () => {
  const [cart, setCart] = useState([]);

  const toggleCart = (item) => {
    setCart((prev) =>
      prev.includes(item) ? prev.filter((i) => i !== item) : [...prev, item]
    );
  };

  const total = cart.reduce((sum, i) => sum + i.price, 0);

  return (
    <div style={{ padding: '20px' }}>
      <h2>👕 의류 상품 목록</h2>
      <div style={{ display: 'flex', gap: '20px' }}>
        {items.map((item) => (
          <div
            key={item.id}
            style={{
              border: '1px solid #ccc',
              borderRadius: '10px',
              padding: '10px',
              textAlign: 'center',
              width: '200px',
            }}
          >
            {/* 이미지 클릭 시 상세페이지로 이동 */}
            <Link to={`/products/${item.id}`}>
              <img
                src={item.image}
                alt={item.name}
                style={{ width: '100%', borderRadius: '8px', cursor: 'pointer' }}
              />
            </Link>
            <h3>{item.name}</h3>
            <p>가격: {item.price.toLocaleString()}원</p>
            <button onClick={() => toggleCart(item)}>
              {cart.includes(item) ? '구매 취소' : '구매'}
            </button>
          </div>
        ))}
      </div>

      <hr />
      <h3>🧾 총 금액: {total.toLocaleString()}원</h3>
    </div>
  );
};

export default Products;
