import { useParams } from 'react-router-dom';
import tshirt from '../assets/tshirt.jpg';
import jacket from '../assets/jacket.jpg';
import pants from '../assets/pants.jpg';

const items = [
  {
    id: 1,
    name: '티셔츠',
    price: 20000,
    desc: '면 100%, 시원하고 편안한 여름용 티셔츠입니다.',
    image: tshirt,
  },
  {
    id: 2,
    name: '자켓',
    price: 50000,
    desc: '가을/겨울용 따뜻한 자켓입니다. 방풍 기능 탑재.',
    image: jacket,
  },
  {
    id: 3,
    name: '바지',
    price: 30000,
    desc: '데일리로 입기 좋은 캐주얼 바지입니다.',
    image: pants,
  },
];

const ProductDetail = () => {
  const { id } = useParams();
  const item = items.find((i) => i.id === parseInt(id));

  if (!item) return <p>상품을 찾을 수 없습니다.</p>;

  return (
    <div style={{ padding: '20px' }}>
      <h2>{item.name}</h2>
      <img
        src={item.image}
        alt={item.name}
        style={{ width: '300px', borderRadius: '10px' }}
      />
      <p style={{ marginTop: '10px' }}>{item.desc}</p>
      <p>가격: {item.price.toLocaleString()}원</p>
    </div>
  );
};

export default ProductDetail;
