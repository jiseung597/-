import { useParams } from 'react-router-dom';
import tshirt from '../assets/tshirt.jpg';
import jacket from '../assets/jacket.jpg';
import pants from '../assets/pants.jpg';

const items = [
  { id: 1, name: '티셔츠', price: 20000, desc: '면 100%, 여름용 티셔츠', image: tshirt },
  { id: 2, name: '자켓', price: 50000, desc: '가을용 자켓, 방풍 기능 포함', image: jacket },
  { id: 3, name: '바지', price: 30000, desc: '편안한 데일리 바지', image: pants }
];

const ProductDetail = () => {
  const { id } = useParams();
  const item = items.find((i) => i.id === parseInt(id));

  if (!item) return <div>상품을 찾을 수 없습니다.</div>;

  return (
    <div>
      <h2>{item.name}</h2>
      <img src={item.image} width="200" />
      <p>{item.desc}</p>
      <p>가격: {item.price.toLocaleString()}원</p>
    </div>
  );
};

export default ProductDetail;
