import { useState } from 'react';
import { Link } from 'react-router-dom';
import tshirt from '../assets/tshirt.jpg';
import jacket from '../assets/jacket.jpg';
import pants from '../assets/pants.jpg';

const items = [
  { id: 1, name: '티셔츠', price: 20000, image: tshirt },
  { id: 2, name: '자켓', price: 50000, image: jacket },
  { id: 3, name: '바지', price: 30000, image: pants }
];

const Products = () => {
  const [cart, setCart] = useState([]);

  const toggleCart = (item) => {
    setCart((prev) =>
      prev.includes(item)
        ? prev.filter((i) => i !== item)
        : [...prev, item]
    );
  };

  const total = cart.reduce((sum, i) => sum + i.price, 0);

  return (
    <div>
      <h2>의류 목록</h2>
      {items.map((item) => (
        <div key={item.id}>
          <img src={item.image} width="150" />
          <h3>{item.name}</h3>
          <p>가격: {item.price.toLocaleString()}원</p>
          <Link to={`/products/${item.id}`}>상세보기</Link>
          <button onClick={() => toggleCart(item)}>
            {cart.includes(item) ? '구매취소' : '구매'}
          </button>
        </div>
      ))}
      <h3>총 합계: {total.toLocaleString()}원</h3>
    </div>
  );
};

export default Products;
